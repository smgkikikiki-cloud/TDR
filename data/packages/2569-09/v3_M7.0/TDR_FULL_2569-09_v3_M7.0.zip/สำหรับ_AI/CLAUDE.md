# TDR Automotive Intelligence — กฎสำหรับ Claude ในโปรเจกต์นี้
ก่อนเปิดหรือนำเข้าข้อมูลใน `data/packages/` หรือไฟล์ `TDR_FULL_*.zip` ให้อ่าน `.claude/skills/tdr-package-import/SKILL.md` ก่อนทุกครั้ง แล้วทำตามขั้นนำเข้าและกฎการแสดงผลในนั้น
