# -*- coding: utf-8 -*-
"""ตรวจแพ็กเกจ Panel ก่อนนำเข้า Supabase (ใช้แค่ Python มาตรฐาน)
ใช้:  python validate_package.py <ไฟล์.zip> [ไฟล์.zip ...]
ผ่านทั้งหมด = exit 0 · มีปัญหา = exit 1 พร้อมรายการ
"""
import csv, hashlib, io, json, sys, zipfile

REQUIRED = {'manifest.json', 'panel.json'}
DATA_COLS = {
    'data/reg_province.csv': ['period', 'province', 'reg_type', 'brand', 'fuel_group', 'reg_count'],
    'data/reg_trend.csv': ['period', 'province', 'reg_type', 'brand', 'model_group_id', 'model_name', 'reg_count'],
    'data/rim_province.csv': ['period', 'province', 'reg_type', 'brand', 'rim_bucket', 'reg_est'],
    'data/tyre_province.csv': ['period', 'province', 'reg_type', 'brand', 'tyre_size', 'rim_inch', 'reg_est'],
    'data/reg_powertrain.csv': ['period', 'province', 'reg_type', 'brand', 'model_group_id', 'model_name', 'fuel_group', 'reg_est', 'reg_min', 'reg_max', 'certainty'],
    'data/coverage.csv': ['period', 'province', 'reg_type', 'brand', 'reg_total', 'reg_tyre_known'],
}
_K = ['period', 'province', 'reg_type', 'brand']
PK = {   # คีย์หลักของแต่ละไฟล์ (ตรงกับ SKILL.md ข้อ 1)
    'data/reg_province.csv': _K + ['fuel_group'], 'data/reg_trend.csv': _K + ['model_group_id'],
    'data/reg_powertrain.csv': _K + ['model_group_id', 'fuel_group', 'certainty'],
    'data/rim_province.csv': _K + ['rim_bucket'], 'data/tyre_province.csv': _K + ['tyre_size', 'rim_inch'], 'data/coverage.csv': _K,
    'dims/model_group.csv': ['model_group_id'], 'dims/brand.csv': ['brand'], 'dims/province.csv': ['province'],
    'dims/fuel.csv': ['fuel_dlt'], 'dims/reg_type.csv': ['reg_type'], 'dims/tyre.csv': ['tyre_size', 'rim_inch'],
}


def check(path):
    errs = []
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        miss = REQUIRED - names
        if miss:
            return [f'ไม่มีไฟล์ {sorted(miss)}']
        man = json.loads(z.read('manifest.json')); panel = json.loads(z.read('panel.json'))
        if man.get('panel_id') != panel.get('panel_id') or man.get('version') != panel.get('version'):
            errs.append('panel_id/version ใน manifest กับ panel.json ไม่ตรงกัน')
        for name, meta in man.get('files', {}).items():
            if name not in names:
                errs.append(f'manifest อ้างถึง {name} แต่ไม่มีใน zip'); continue
            if hashlib.md5(z.read(name)).hexdigest() != meta['md5']:
                errs.append(f'md5 ของ {name} ไม่ตรง')
        extra = names - set(man.get('files', {})) - {'manifest.json'}
        if extra:
            errs.append(f'ไฟล์ที่ไม่อยู่ใน manifest: {sorted(extra)}')
        if not man.get('qc_passed'):
            errs.append('QC ใน manifest ไม่ผ่าน')
        if len(man.get('confirmed_by', [])) < 2:
            errs.append('ยังไม่มีผู้ยืนยัน 2 คนใน confirmed_by (เติมหลังตรวจร่วมกัน)')
        for name, cols in DATA_COLS.items():
            if name in names:
                rd = csv.reader(io.TextIOWrapper(z.open(name), encoding='utf-8'))
                head = next(rd)
                if head != cols:
                    errs.append(f'{name}: คอลัมน์ {head} ≠ {cols}')
                n = 0
                for row in rd:
                    n += 1
                    if not (man['period_from'] <= row[0] <= man['period_to']):
                        errs.append(f'{name}: งวด {row[0]} อยู่นอกช่วง manifest'); break
                if n == 0:
                    errs.append(f'{name}: ไม่มีข้อมูล')
        for name, key in PK.items():   # คีย์ต้องไม่ซ้ำ (ข้ามไฟล์ที่ไม่มีคอลัมน์คีย์ครบ เช่น แพ็กเกจรุ่นเก่า)
            if name in names:
                rd = csv.DictReader(io.TextIOWrapper(z.open(name), encoding='utf-8-sig'))
                if not set(key) <= set(rd.fieldnames or []):
                    continue
                seen, dup, blank = set(), 0, 0
                for row in rd:
                    k = tuple(row[c] for c in key)
                    if '' in k:
                        blank += 1
                    if k in seen:
                        dup += 1
                    seen.add(k)
                if dup:
                    errs.append(f'{name}: คีย์ {key} ซ้ำ {dup:,} แถว')
                if blank:
                    errs.append(f'{name}: คีย์ {key} ว่าง {blank:,} แถว')
        allowed = set(sum(DATA_COLS.values(), []))
        bad = [c for c in panel.get('export_columns', []) if c not in allowed]
        if bad:
            errs.append(f'export_columns มีคอลัมน์ที่ไม่มีในข้อมูล: {bad}')
    return errs


if __name__ == '__main__':
    fail = False
    for p in sys.argv[1:]:
        e = check(p)
        print(('ผ่าน  ' if not e else 'ไม่ผ่าน ') + p)
        for x in e:
            print('   -', x)
        fail |= bool(e)
    sys.exit(1 if fail else 0)
